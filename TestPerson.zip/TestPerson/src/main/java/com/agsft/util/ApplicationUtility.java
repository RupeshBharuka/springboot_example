package com.agsft.util;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j;


@Log4j
@Component
public class ApplicationUtility {
	@Autowired
	private MessageSource messageSource;
	
	public String getMessage(String key){
		try{
			log.info("Reading properties value...!");
			return messageSource.getMessage(key, null, Locale.US);
		}catch(NoSuchMessageException e){
			log.error("Failed to get property file value : " +e);
			return "Failed to read message"; //you should send null or something instead of sending black message
		}
		
	}
}
