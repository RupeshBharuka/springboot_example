package com.agsft.util;

public final class PersonUtility {
	
	private PersonUtility(){
		//This class can not be instantiated
	}
	
	public static boolean isNullOrEmpty(String value){
		return (value == null || "".equalsIgnoreCase(value));
	}
}
