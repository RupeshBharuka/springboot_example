package com.agsft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;



import com.google.common.base.Predicate;

import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import static springfox.documentation.builders.PathSelectors.regex;
import static com.google.common.base.Predicates.or;

@SpringBootApplication(scanBasePackages = "com.agsft")
@EnableSwagger2
public class TestPersonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestPersonApplication.class, args);
	}
	
	@Bean(name="messageSource")
	public MessageSource getMessageSource(){
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		//You can specify multiple properties files here separated by comma
		messageSource.setBasenames("message");
		messageSource.setDefaultEncoding("UTF-8");
		
		return messageSource;
	}
	
	@Bean
	public Docket postsApi() {
		return new Docket(DocumentationType.SWAGGER_2).groupName("public-api").apiInfo(apiInfo()).select()
		.paths(postPaths()).build();
	}

	private Predicate<String> postPaths() {
		return or(regex("/*.*"), regex("/*.*"));
	}

	private ApiInfo apiInfo() {
	ApiInfo apiInfo = new ApiInfo("Spring Boot REST API", "Spring Boot REST API for Company App", "1.0",
	"Terms of service", new Contact("Snehal Dhane", "", ""), "Apache License Version 2.0",
	"https://www.apache.org/licenses/LICENSE-2.0");
	
		return apiInfo;
	}
}
