package com.agsft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;

@SpringBootApplication(scanBasePackages = "com.agsft")
public class TestPersonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestPersonApplication.class, args);
	}
	
	@Bean(name="messageSource")
	public MessageSource getMessageSource(){
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		//You can specify multiple properties files here separated by comma
		messageSource.setBasenames("message");
		messageSource.setDefaultEncoding("UTF-8");
		
		return messageSource;
	}
}
