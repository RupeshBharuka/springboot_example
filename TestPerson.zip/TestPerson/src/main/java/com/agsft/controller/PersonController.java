package com.agsft.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.agsft.model.Person;
import com.agsft.model.ui.PersonModel;
import com.agsft.service.PersonService;
import com.agsft.util.ApplicationUtility;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j;

@Log4j
@RestController
@Api(value="Person Application", description="Operations related to person")
public class PersonController {
	@Autowired
	private PersonService personService;
	
	@Autowired
	private ApplicationUtility applicationUtility;
	
	public static final String ADD_RECORD_SUCCESS = "add.record.success";
	public static final String UPDATE_RECORD_SUCCESS = "update.record.success";
	public static final String DELETE_RECORD_SUCCESS = "delete.record.success";

	
	@RequestMapping(value="/get/person/name/{city}", method=RequestMethod.GET)
	public Person getPersonNameByCity(@PathVariable("city")String cityName){
		return personService.getPersonByCityName(cityName);
	}
	
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@RequestMapping(value="/add/record",method=RequestMethod.POST)
	public String addRecord(@RequestBody PersonModel personModel){
		personService.addPersonRecord(personModel);
		
//		return "Person record added successfully!";
		return applicationUtility.getMessage(ADD_RECORD_SUCCESS);
	}
	
	@ApiOperation(value="Add All")
	@Produces
	@Consumes
	@RequestMapping(value="/add/all/records", method = RequestMethod.POST)
	public String addAllRecords(@RequestBody List<PersonModel> personModel){
		personService.addAllPersonRecords(personModel);	
		return "Person records added successfully!";
	}
	
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@RequestMapping(value="/update/record/{personId}", method=RequestMethod.PUT)
	public String updateRecord(@PathVariable("personId")int personId, @RequestBody PersonModel personModel){
		Person person = personService.getPersonById(personId);
		
		log.info("Person Hash Code Before service call : " +person.hashCode());
		personService.updatePersonRecord(personModel, person);
		log.info("Person Hash Code After service call : " +person.hashCode());
		return applicationUtility.getMessage(UPDATE_RECORD_SUCCESS);
	}
	
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@RequestMapping(value="/delete/record/{personId}", method=RequestMethod.DELETE)
	public String deleteRecord(@PathVariable("personId")int personId){
		Person person = personService.getPersonById(personId);
		
		personService.deletePersonRecord(person);
		
		return applicationUtility.getMessage(DELETE_RECORD_SUCCESS);
	}
	
}
