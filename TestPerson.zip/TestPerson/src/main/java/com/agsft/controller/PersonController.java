package com.agsft.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.agsft.model.Person;
import com.agsft.model.ui.PersonModel;
import com.agsft.service.PersonService;
import com.agsft.util.ApplicationUtility;

import ch.qos.logback.classic.Logger;
import lombok.extern.log4j.Log4j;

@Log4j
@RestController
public class PersonController {
	@Autowired
	private PersonService personService;
	
	@Autowired
	private ApplicationUtility applicationUtility;
	
	public static final String ADD_RECORD_SUCCESS = "add.record.success";
	public static final String UPDATE_RECORD_SUCCESS = "update.record.success";
	public static final String DELETE_RECORD_SUCCESS = "delete.record.success";

	
	@RequestMapping(value="/get/person/name/{city}", method=RequestMethod.GET)
	public Person getPersonNameByCity(@PathVariable("city")String cityName){
		return personService.getPersonByCityName(cityName);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@RequestMapping(value="/add/record")
	public String addRecord(@RequestBody PersonModel personModel){
		personService.addPersonRecord(personModel);
		
//		return "Person record added successfully!";
		return applicationUtility.getMessage(ADD_RECORD_SUCCESS);
	}
	
	@POST
	@Produces
	@Consumes
	@RequestMapping(value="/add/all/records")
	public String addAllRecords(@RequestBody List<PersonModel> personModel){
		personService.addAllPersonRecords(personModel);	
		return "Person records added successfully!";
	}
	
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@RequestMapping(value="/update/record/{personId}")
	public String updateRecord(@PathVariable("personId")int personId, @RequestBody PersonModel personModel){
		Person person = personService.getPersonById(personId);
		
		log.info("Person Hash Code Before service call : " +person.hashCode());
		personService.updatePersonRecord(personModel, person);
		log.info("Person Hash Code After service call : " +person.hashCode());
		return applicationUtility.getMessage(UPDATE_RECORD_SUCCESS);
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@RequestMapping(value="/delete/record/{personId}")
	public String deleteRecord(@PathVariable("personId")int personId){
		Person person = personService.getPersonById(personId);
		
		personService.deletePersonRecord(person);
		
		return applicationUtility.getMessage(DELETE_RECORD_SUCCESS);
	}
	
}
