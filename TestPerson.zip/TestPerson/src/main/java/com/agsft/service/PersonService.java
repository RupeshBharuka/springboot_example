package com.agsft.service;

import com.agsft.model.Person;

public interface PersonService {
	public Person getPersonByCityName(String cityName);
}
