package com.agsft.service;

import java.util.List;

//import javax.mail.MessagingException;

import com.agsft.model.Person;
import com.agsft.model.ui.PersonModel;

public interface PersonService {
	public void addPersonRecord(PersonModel personModel);
	public void updatePersonRecord(PersonModel personModel, Person person);
	public void deletePersonRecord(Person person);
	public Person getPersonByCityName(String cityName);
	public Person getPersonById(int personId);
	public void addAllPersonRecords(List<PersonModel> personModel);
//	public void sendPersonAddRecordNotification(Person person)throws MessagingException;
}
