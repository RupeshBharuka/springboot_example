package com.agsft.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agsft.model.Person;
import com.agsft.model.ui.PersonModel;
import com.agsft.repository.PersonRepository;
import com.agsft.service.PersonService;
import com.agsft.util.PersonUtility;

import lombok.extern.log4j.Log4j;

//service layer
@Service
@Log4j
public class PersonServiceImpl implements PersonService{

	@Autowired
	private PersonRepository personRepo;

	@Override
	public Person getPersonByCityName(String cityName) {
		return personRepo.getPersonByCityName(cityName);
	}

	@Override
	public void addPersonRecord(PersonModel personModel) {
		Person person = new Person();
		
		person.setPersonName(personModel.getPersonName());
		person.setCityName(personModel.getCityName());
		
		personRepo.save(person);
	}

	@Override
	public void updatePersonRecord(PersonModel personModel, Person person) {

		log.info("Person Hash COde in update : " +person.hashCode());
		
		if(!PersonUtility.isNullOrEmpty(personModel.getPersonName())){
			person.setPersonName(personModel.getPersonName());
		}
		
		if(!PersonUtility.isNullOrEmpty(personModel.getCityName())){
			person.setCityName(personModel.getCityName());
		}
		
		personRepo.save(person);
		
		log.info("Person Hash COde in update2 : " +person.hashCode());
	}

	@Override
	public Person getPersonById(int personId) {
		return personRepo.getPersonById(personId);
	}

	@Override
	public void deletePersonRecord(Person person) {
		personRepo.delete(person);
	}
	
}
