package com.agsft.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.agsft.model.Person;
import com.agsft.repository.PersonRepository;
import com.agsft.service.PersonService;

@Service
public class PersonServiceImpl implements PersonService{

	@Autowired
	private PersonRepository personRepo;

	@Override
	public Person getPersonByCityName(String cityName) {
		return personRepo.getPersonByCityName(cityName);
	}
	
}
