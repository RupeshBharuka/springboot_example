package com.agsft.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.agsft.model.Person;
import com.agsft.model.ui.PersonModel;
import com.agsft.model.vt.PersonVtModel;
import com.agsft.repository.PersonRepository;
import com.agsft.service.PersonService;
import com.agsft.util.PersonUtility;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j;

//service layer
@Service
@Log4j
public class PersonServiceImpl implements PersonService{

	@Autowired
	private PersonRepository personRepo;

	@Value("${mail.from}")
	private String mailFrom;

	@Autowired
	private JavaMailSender javaMailSender;
	
	@Autowired
	private VelocityEngine velocityEngine;
	
	public static final String PERSON_CREATE_NOTIFICATION = "personCreationNotification.vm";

	
	@Override
	public Person getPersonByCityName(String cityName) {
		return personRepo.getPersonByCityName(cityName);
	}

	@Override
	public void addPersonRecord(PersonModel personModel) {
		Person person = new Person();
		
		person.setPersonName(personModel.getPersonName());
		person.setCityName(personModel.getCityName());
		
		personRepo.save(person);
		
		try {
			sendPersonAddRecordNotification(person);
		} catch (MessagingException e) {
			log.error("Email sending failed" +e);
		}
	}

	@Override
	public void updatePersonRecord(PersonModel personModel, Person person) {

		log.info("Person Hash Code in update : " +person.hashCode());
		
		if(!PersonUtility.isNullOrEmpty(personModel.getPersonName())){
			person.setPersonName(personModel.getPersonName());
		}
		
		if(!PersonUtility.isNullOrEmpty(personModel.getCityName())){
			person.setCityName(personModel.getCityName());
		}
		
		personRepo.save(person);
		
		log.info("Person Hash Code in update2 : " +person.hashCode());
	}

	@Override
	public Person getPersonById(int personId) {
		return personRepo.getPersonById(personId);
	}

	@Override
	public void deletePersonRecord(Person person) {
		personRepo.delete(person);
	}

	@Override
	public void addAllPersonRecords(List<PersonModel> personModel) {
//		personRepo.save(personModel);
		List<Person>personList = new ArrayList<>();
		personModel.forEach(person->{
			Person p = new Person();
			p.setPersonName(person.getPersonName());
			p.setCityName(person.getCityName());
			
			personList.add(p);
		});
		
		personRepo.save(personList);
	}

	@Override
	public void sendPersonAddRecordNotification(Person person) throws MessagingException {
		PersonVtModel personVtModel = new PersonVtModel();
		personVtModel.setPersonName(person.getPersonName());
		personVtModel.setCityName(person.getCityName());
		
		String templateFile = PERSON_CREATE_NOTIFICATION;
		
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, false, "UTF-8");
		
		
		helper.setTo("bharuka.rupesh@gmail.com");
		helper.setFrom(mailFrom);
		helper.setSubject("Person Create Notification");
		/*helper.setText("Hi, How are you?");*/
		
		/*javaMailSender.send(mimeMessage);*/
		
		ObjectMapper m = new ObjectMapper();
		Map<String, Object> props = m.convertValue(templateFile, Map.class);
		String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, templateFile, "UTF-8", props);
		
		mimeMessage.setContent(text, "text/html");
		javaMailSender.send(mimeMessage);
		
		log.info("Email sent successfully");
	}
	
}
