package com.agsft.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.agsft.model.Person;

@Repository
public interface PersonRepository extends CrudRepository<Person, Integer>{
	
	@Query("SELECT p FROM Person p WHERE p.cityName=:cityName")
	public Person getPersonByCityName(@Param("cityName")String cityName);
}
