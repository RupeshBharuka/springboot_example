package com.agsft.model.ui;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.Data;

@Data
public class PersonModel {
	@NotNull
	@NotEmpty
	private String personName;
	
	@NotNull
	@NotEmpty
	private String cityName;
}
