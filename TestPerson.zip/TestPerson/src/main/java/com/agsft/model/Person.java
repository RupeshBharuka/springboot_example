package com.agsft.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="person")
public class Person {
	private static final long serialVersionUID = 175046424681330074L;
	
	@Id
	@Column(name="p_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int personId;
	
	@Column(name="p_name")
	private String personName;
	
	@Column(name="city")
	private String cityName;

	public Person(){
		this.personId = 0;
		this.personName = "";
		this.cityName = "";
	}

	public int getPersonId() {
		return personId;
	}

	public void setPersonId(int personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
}
