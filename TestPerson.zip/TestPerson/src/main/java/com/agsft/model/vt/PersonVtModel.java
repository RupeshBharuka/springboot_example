package com.agsft.model.vt;

import lombok.Data;

@Data
public class PersonVtModel {
	private String personName;
	private String cityName;
}
